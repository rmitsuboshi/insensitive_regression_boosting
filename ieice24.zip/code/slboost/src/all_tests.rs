use polars::prelude::*;
use rayon::prelude::*;

use miniboosts::prelude::*;

use std::fs::OpenOptions;
use std::io::prelude::*;


// -------------------------------------------------------------
// Constant parameters.

/// Boosting parameters
const TOLERANCE: f64 = 0.1;

/// CAP_RATIOS.len()
// const CAP_SIZE: usize = 5;

/// Capping parameters
// const CAP_RATIOS: [f64; CAP_SIZE] = [0.1, 0.2, 0.3, 0.4];
// const CAP_RATIOS: [f64; CAP_SIZE] = [0.1, 0.2, 0.3, 0.4, 0.5];


// /// Number of fold size
// const FOLD_SIZE: usize = 5;

// -------------------------------------------------------------


/// Read the input file (with CSV format) into
/// the pair of (Data, Label)
fn df(file: &str) -> (DataFrame, Series) {
    let mut data = CsvReader::from_path(file)
        .unwrap()
        .has_header(true)
        .finish()
        .unwrap();

    let target = data.drop_in_place(&"target").unwrap();

    (data, target)
}


/// Run the cross validations,
pub(crate) fn all_tests(path: &str, out_prefix: &str) {
    println!("PATH: {path}");


    // println!("  Running boosting algorithm for training sets");
    // for ratio in CAP_RATIOS {
    //     (1..=FOLD_SIZE).into_par_iter()
    //         .for_each(|k| {
    //             let file = format!("{path}/train-{k}.csv");
    //             let (data, target) = df(&file);

    //             let train_size = data.shape().0;


    //             let tree = RTree::init(&data, &target)
    //                 .loss_type(LossType::L1)
    //                 .max_depth(1);


    //             // ---------------------------------------------------
    //             // SLBoost
    //             let mut booster = SLBoost::init(&data, &target)
    //                 .nu(ratio * train_size as f64)
    //                 .tolerance(TOLERANCE);

    //             let f = booster.run(&tree);
    //             let json_file = format!("{out_prefix}-ratio-{ratio}-fold-{k}.json");
    //             let mut file = OpenOptions::new()
    //                 .write(true)
    //                 .create(true)
    //                 .open(json_file)
    //                 .unwrap();

    //             let f_str = serde_json::to_string(&f).unwrap();
    //             file.write_all(f_str.as_bytes()).unwrap();
    //             println!("Finished {k}-th fold for cap: {ratio:.2}");
    //         });

    //     println!("Finished for cap: {ratio:.2}");
    // }
    // println!("  done.");
    let cap_ratios = vec![0.0, 0.001, 0.01, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
    // let cap_ratios = vec![0.0, 0.001, 0.01, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 2.0, 5.0, 10.0];

    cap_ratios.into_par_iter()
        .for_each(|old_ratio| {
            let file = format!("{path}/train.csv");
            let (data, target) = df(&file);

            let train_size = data.shape().0;

            let mut ratio = old_ratio;
            if old_ratio == 0.0 {
                ratio = 1.0 / train_size as f64;
            }


            let tree = RTree::init(&data, &target)
                .loss_type(LossType::L1)
                .max_depth(1);


            // ---------------------------------------------------
            // SLBoost
            let mut booster = SLBoost::init(&data, &target)
                .nu(ratio * train_size as f64)
                .tolerance(TOLERANCE);

            let f = booster.run(&tree);
            let json_file = format!("{out_prefix}-ratio-{old_ratio}.json");
            let mut file = OpenOptions::new()
                .write(true)
                .create(true)
                .open(json_file)
                .unwrap();

            let f_str = serde_json::to_string(&f).unwrap();
            file.write_all(f_str.as_bytes()).unwrap();


            let predictions = f.predict_all(&data);
            let mut losses = target.f64()
                .unwrap()
                .into_iter()
                .zip(predictions)
                .map(|(y, p)| (y.unwrap() - p).abs())
                .collect::<Vec<f64>>();

            // Sort the loss values in **descending** order
            losses.sort_by(|a, b| b.partial_cmp(&a).unwrap());
            let nu = ratio * train_size as f64;
            let ub = 1.0 / nu;
            let mut total = 1.0;
            let mut objval = 0.0;
            for l in losses {
                if total <= ub {
                    objval += total * l;
                    break;
                } else {
                    objval += ub * l;
                    total -= ub;
                }
            }

            println!("Objective value (nu ratio is: {old_ratio}): {objval}");
            println!("Finished for cap: {old_ratio:.3}");
        });
}

