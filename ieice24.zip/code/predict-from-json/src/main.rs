use polars::prelude::*;
use miniboosts::prelude::*;


use std::fs;

// For shorthand
type F = CombinedHypothesis<RTreeRegressor>;

fn main() {
    let mut args = std::env::args().skip(1);
    let json_file = args.next()
        .expect("[USAGE] ./exec [JSON FILE] [TRAIN FILE] [OUTPUT FILE]");

    let content = fs::read_to_string(json_file).unwrap();

    let f: F = serde_json::from_str(&content).unwrap();


    let data_file = args.next()
        .expect("[USAGE] ./exec [JSON FILE] [TRAIN FILE] [OUTPUT FILE]");
    let mut data = CsvReader::from_path(&data_file)
        .unwrap()
        .has_header(true)
        .finish()
        .unwrap();

    let target = data.drop_in_place(&"target")
        .unwrap();


    let predictions = f.predict_all(&data);

    assert!(predictions.iter().all(|&p| p < 1e9));


    println!("L1-distance");


    target.f64()
        .unwrap()
        .into_iter()
        .zip(predictions)
        .for_each(|(t, p)| {
            let diff = (t.unwrap() - p).abs();
            assert!(diff < 1e9);
            println!("{diff}");
        });
}
