# About this directory

Many paper depict the learning curve to compare the algorithms.
As long as I know, They implement their algorithm and their competitives 
by theirselves. I think that implementing competitives are waste of time.

