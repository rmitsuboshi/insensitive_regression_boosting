# coding: utf-8

# Run LightGBM
# This program restricts the depth of each tree at most 1.
# (Stump)

import pandas as pd
import lightgbm as lgb
import numpy as np

# Path to the dataset
DATA_PATH = '/home/mitsuboshi/dataset'
FILES = ['boston_housing', 'concrete', 'california-housing', 'diabetes']


# LightGBM parameter
params = {
    "task": "train",
    "objective": "regression_l1",
    
    "boosting": "gbdt",

    
    "max_depth": 1,
    "min_data_in_leaf": 1,
    "num_leaves": 2,
    
    "seed": 1234,
    "deterministic": True,
    
    "lambda_l1": 1.0,
    
    "min_data_in_bin": 1,
    
    "enable_bundle": False,
    
    "verbose": -1,
}


# Parameters
ps = [0.1, 0.5, 1.0, 10.0, 20.0, 50.0, 100.0]


for dataset in FILES:
    for p in ps:
        # Set the regularization parameter as `p`.
        params["lambda_l1"] = p
        

        # If the dataset is the one in sklearn, set the path as follows:
        if dataset in ['california-housing', 'diabetes']:
            trainfile = f'{DATA_PATH}/sklearn-dataset/{dataset}/train.csv'

        else:
            trainfile = f'{DATA_PATH}/{dataset}/fold/train.csv'
        # Read data
        df = pd.read_csv(trainfile)

        # No binning
        params['max_bin'] = df.shape[0]

        # Split into data and label
        Y = df['target']
        X = df.drop('target', axis=1)

        train_data = lgb.Dataset(X, label=Y)

        gbm = lgb.train(params, train_data)

        # -----------------------

        # Compute the L1-distances from prediction to actual label over training examples
        predictions = gbm.predict(X)
        distances = np.abs([pred - y for pred, y in zip(predictions, Y)])
        
        # Write to CSV file
        filename = f'{dataset}-param-{p}-train.csv'
        distances = pd.DataFrame({'L1-distance': distances})
        distances.to_csv(filename, index=False)


        # -----------------------
        # If the dataset is the one in sklearn, set the path as follows:
        if dataset in ['california-housing', 'diabetes']:
            testfile = f'{DATA_PATH}/sklearn-dataset/{dataset}/test.csv'

        else:
            testfile = f'{DATA_PATH}/{dataset}/fold/test.csv'
        # Read data
        df = pd.read_csv(testfile)

        # Split into data and label
        Y = df['target']
        X = df.drop('target', axis=1)

        # Compute the L1-distances from prediction to actual label over test examples
        predictions = gbm.predict(X)
        distances = np.abs([pred - y for pred, y in zip(predictions, Y)])
        
        # Write to CSV file
        filename = f'{dataset}-param-{p}-test.csv'
        distances = pd.DataFrame({'L1-distance': distances})
        distances.to_csv(filename, index=False)
