use polars::prelude::*;
use miniboosts::prelude::*;


#[cfg(test)]
pub mod qpboost_tests {
    use super::*;

    #[test]
    pub fn benchmark() {
        let path = "/Users/ryotaromitsuboshi/Documents/Datasets/benchmarks";
        let file = format!("{path}/banana.csv");
        let mut data = CsvReader::from_path(file)
            .unwrap()
            .has_header(true)
            .finish()
            .unwrap();


        let target = data.drop_in_place(&"class").unwrap();


        let m = data.shape().0 as f64;
        let nu = 0.1;

        let mut booster = QPBoost::init(&data, &target)
            .tolerance(0.01)
            .nu(nu * m);
        // let wl = DTree::init(&data, &target)
        //     .criterion(Criterion::Edge)
        //     .max_depth(2);
        let wl = DTree::init(&data, &target)
            .max_depth(2)
            .criterion(Criterion::Edge);


        let f = booster.run(&wl);
        println!("{f:?}");

        let err = target.i64()
            .expect("The target class is not a dtype of i64")
            .into_iter()
            .zip(f.predict_all(&data))
            .map(|(y, p)| if y.unwrap() != p { 1.0 } else { 0.0 })
            .sum::<f64>() / m;

        println!("QPBoost train error: {err}");
        assert!(true);
    }
}


// #[cfg(test)]
// pub mod benchmarks_tests {
//     use super::*;
//     // #[test]
//     // fn lpboost_german() {
//     //     let path = "/Users/ryotaromitsuboshi/Documents/Datasets/benchmarks";
//     //     let file = format!("{path}/german.csv");
//     //     let mut data = CsvReader::from_path(file)
//     //         .unwrap()
//     //         .has_header(true)
//     //         .finish()
//     //         .unwrap();
// 
// 
//     //     let target = data.drop_in_place(&"class").unwrap();
// 
// 
//     //     let m = data.shape().0 as f64;
//     //     let nu = 0.2;
// 
//     //     let mut booster = LPBoost::init(&data, &target)
//     //         .tolerance(0.1)
//     //         .nu(nu * m);
//     //     // let wl = DTree::init(&data, &target)
//     //     //     .criterion(Criterion::Edge)
//     //     //     .max_depth(2);
//     //     let wl = GaussianNB::init(&data, &target);
// 
// 
//     //     let f = booster.run(&wl, &data, &target);
//     //     println!("{f:?}");
// 
//     //     let err = target.i64()
//     //         .expect("The target class is not a dtype of i64")
//     //         .into_iter()
//     //         .zip(f.predict_all(&data))
//     //         .map(|(y, p)| if y.unwrap() != p { 1.0 } else { 0.0 })
//     //         .sum::<f64>() / m;
// 
//     //     println!("LPBoost train error: {err}");
//     //     assert!(true);
//     // }
// 
// 
//     // #[test]
//     // fn erlpboost_german() {
//     //     let path = "/Users/ryotaromitsuboshi/Documents/Datasets/benchmarks";
//     //     let file = format!("{path}/german.csv");
//     //     let mut data = CsvReader::from_path(file)
//     //         .unwrap()
//     //         .has_header(true)
//     //         .finish()
//     //         .unwrap();
// 
// 
//     //     let target = data.drop_in_place(&"class").unwrap();
// 
// 
//     //     let m = data.shape().0 as f64;
//     //     let nu = 0.2;
// 
//     //     let mut booster = ERLPBoost::init(&data, &target)
//     //         .tolerance(0.1)
//     //         .nu(nu * m);
//     //     let dtree = DTree::init(&data, &target)
//     //         .criterion(Criterion::Edge)
//     //         .max_depth(1);
// 
// 
//     //     let f = booster.run(&dtree, &data, &target);
//     //     let err = target.i64()
//     //         .expect("The target class is not a dtype of i64")
//     //         .into_iter()
//     //         .zip(f.predict_all(&data))
//     //         .map(|(y, p)| if y.unwrap() != p { 1.0 } else { 0.0 })
//     //         .sum::<f64>() / m;
// 
//     //     println!("f: {f:?}");
//     //     println!("ERLPBoost train error: {err}");
//     //     assert!(true);
//     // }
// 
// 
//     // #[test]
//     // fn cerlpboost_german() {
//     //     let path = "/Users/ryotaromitsuboshi/Documents/Datasets/benchmarks";
//     //     let file = format!("{path}/german.csv");
//     //     let mut data = CsvReader::from_path(file)
//     //         .unwrap()
//     //         .has_header(true)
//     //         .finish()
//     //         .unwrap();
// 
// 
//     //     let target = data.drop_in_place(&"class").unwrap();
// 
// 
//     //     let m = data.shape().0 as f64;
//     //     let nu = 0.2;
// 
//     //     let mut booster = CERLPBoost::init(&data, &target)
//     //         .tolerance(0.1)
//     //         .nu(nu * m);
//     //     let dtree = DTree::init(&data, &target)
//     //         .criterion(Criterion::Edge)
//     //         .max_depth(1);
// 
// 
//     //     let f = booster.run(&dtree, &data, &target);
//     //     let err = target.i64()
//     //         .expect("The target class is not a dtype of i64")
//     //         .into_iter()
//     //         .zip(f.predict_all(&data))
//     //         .map(|(y, p)| if y.unwrap() != p { 1.0 } else { 0.0 })
//     //         .sum::<f64>() / m;
// 
//     //     println!("f: {f:?}");
//     //     println!("Corrective ERLPBoost train error: {err}");
//     //     assert!(true);
//     // }
// 
// 
//     // #[test]
//     // fn mlpboost_german() {
//     //     let path = "/Users/ryotaromitsuboshi/Documents/Datasets/benchmarks";
//     //     let file = format!("{path}/german.csv");
//     //     let mut data = CsvReader::from_path(file)
//     //         .unwrap()
//     //         .has_header(true)
//     //         .finish()
//     //         .unwrap();
// 
// 
//     //     let target = data.drop_in_place(&"class").unwrap();
// 
// 
//     //     let m = data.shape().0 as f64;
//     //     let nu = 0.2;
// 
//     //     let mut booster = MLPBoost::init(&data, &target)
//     //         .tolerance(0.1)
//     //         .nu(nu * m)
//     //         .primary(Primary::ShortStep)
//     //         .stop_condition(StopCondition::ObjVal);
// 
//     //     // let dtree = DTree::init(&data, &target)
//     //     //     .criterion(Criterion::Edge)
//     //     //     .max_depth(1);
//     //     let wl = GaussianNB::init(&data, &target);
// 
// 
//     //     let f = booster.run(&wl, &data, &target);
//     //     println!("{f:?}");
// 
//     //     let err = target.i64()
//     //         .expect("The target class is not a dtype of i64")
//     //         .into_iter()
//     //         .zip(f.predict_all(&data))
//     //         .map(|(y, p)| if y.unwrap() != p { 1.0 } else { 0.0 })
//     //         .sum::<f64>() / m;
// 
//     //     println!("MLPBoost train error: {err}");
//     //     assert!(true);
//     // }
// }

// pub mod tree_test {
//     use super::*;
// 
//     #[test]
//     fn regression_tree_test() {
//         let path = "\
//             /Users/ryotaroMitsuboshi/Documents/GitHub/rmitsuboshi/\
//             miniboosts/tests/boston_housing.csv\
//         ";
//         let mut data = CsvReader::from_path(path)
//             .unwrap()
//             .has_header(true)
//             .finish()
//             .unwrap();
// 
// 
//         let target = data.drop_in_place(&"MEDV").unwrap();
// 
// 
//         let n_sample = data.shape().0 as f64;
//         let dist = vec![1.0 / n_sample; n_sample as usize];
// 
// 
//         let depth = 3;
//         let tree = RTree::init(&data, &target)
//             .max_depth(depth);
// 
// 
//         let f = tree.produce(&data, &target, &dist[..]);
//         println!("{f:?}");
// 
//         let err = target.f64()
//             .expect("The target class is not a dtype of f64")
//             .into_iter()
//             .zip(f.predict_all(&data))
//             .map(|(y, p)| (y.unwrap() - p).powi(2))
//             .sum::<f64>()
//             / n_sample;
// 
//         println!("train error (decision tree of depth {depth}): {err}");
// 
//         let out_path = "\
//             /Users/ryotaroMitsuboshi/Documents/GitHub/rmitsuboshi/\
//             miniboosts/tests/boston.dot\
//         ";
// 
//         f.to_dot_file(out_path)
//             .unwrap();
//         assert!(true);
//     }
// 
//     #[test]
//     fn decision_tree_test() {
//         let path = "\
//             /Users/ryotaroMitsuboshi/Documents/GitHub/rmitsuboshi/\
//             miniboosts/tests/iris.csv\
//         ";
//         let mut data = CsvReader::from_path(path)
//             .unwrap()
//             .has_header(true)
//             .finish()
//             .unwrap();
// 
// 
//         let target = data.drop_in_place(&"class").unwrap();
// 
// 
//         let n_sample = data.shape().0 as f64;
//         let dist = vec![1.0 / n_sample; n_sample as usize];
// 
//         let depth = 3;
//         let tree = DTree::init(&data, &target)
//             .max_depth(depth);
// 
// 
//         let f = tree.produce(&data, &target, &dist[..]);
//         println!("{f:?}");
// 
//         let err = target.i64()
//             .expect("The target class is not a dtype of i64")
//             .into_iter()
//             .zip(f.predict_all(&data))
//             .map(|(y, p)| if y.unwrap() != p { 1.0 } else { 0.0 })
//             .sum::<f64>()
//             / n_sample;
// 
//         println!("Train error (regression tree of depth {depth}): {err}");
// 
//         let out_path = "\
//             /Users/ryotaroMitsuboshi/Documents/GitHub/rmitsuboshi/\
//             miniboosts/tests/iris.dot\
//         ";
// 
//         f.to_dot_file(out_path)
//             .unwrap();
//         assert!(true);
//     }
// }

