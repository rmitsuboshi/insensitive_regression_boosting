//! This file defines `LogitBoost` based on the book
//! ``Boosting: Foundations and Algorithms''
//! by Robert E. Schapire and Yoav Freund.

use polars::prelude::*;
use rayon::prelude::*;


use crate::{
    Classifier,
    CombinedClassifier,
    BaseLearner,
    Booster,
};


pub struct LogitBoost {
    /// The number of training examples.
    n_sample: usize,
    /// Terminated iteration.
    terminated: usize,
}


impl LogitBoost {
    pub fn init(data: &DataFrame, _target: &Series) -> Self {
        let n_sample = df.shape().0;

        Self {
            n_sample,
            terminated: usize::MAX,
        }
    }


    pub fn max_loop(&self) -> usize {
        todo!()
    }
}



impl<C> Booster<C> for LogitBoost
    where C: Classifier,
{
    fn run<B>(
        &mut self,
        base_learner: &B,
        data:         &DataFrame,
        target:       &Series,
    ) -> CombinedClassifier<C>
        where B: BaseLearner<Clf = C>
    {
        let max_iter = self.max_loop();

        // Set of weights & classifiers
        let weights = Vec::new();
        let clfs = Vec::new();

        for t in 1..=max_iter {
        }
    }
}


