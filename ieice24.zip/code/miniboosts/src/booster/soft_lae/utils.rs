use polars::prelude::*;

use crate::Regressor;


/// Returns the residual vector `y - F(x)`
/// for all instances (x, y) in the training examples.
/// Note that this function does not take `.abs()`.
pub(super) fn residuals<'a, R>(
    data: &'a DataFrame,
    target: &'a Series,
    regressors: &'a [R],
    weights: &'a [f64],
) -> impl Iterator<Item=f64> + 'a
    where R: Regressor
{
    target.f64()
        .expect("The target is not a dtype f64")
        .into_iter()
        .enumerate()
        .map(|(i, y)| {
            let y = y.unwrap();
            let p = predict(i, data, regressors, weights);
            y - p
        })
}


pub(super) fn residuals_of_h<'a, R>(
    data: &'a DataFrame,
    target: &'a Series,
    h: &'a R,
) -> impl Iterator<Item=f64> + 'a
    where R: Regressor
{
    target.f64()
        .expect("The target is not a dtype f64")
        .into_iter()
        .enumerate()
        .map(|(i, y)| y.unwrap() - h.predict(data, i))
}


pub(super) fn lae_of<R>(
    data: &DataFrame,
    target: &Series,
    dist: &[f64],
    regressors: &[R],
    weights: &[f64]
) -> f64
    where R: Regressor
{
    residuals(data, target, regressors, weights)
        .zip(dist)
        .map(|(r, d)| d * r.abs())
        .sum::<f64>()
}


/// Returns the average least absolute error of h
/// with respect to the given distribution.
pub(super) fn lae_of_h<R>(
    data: &DataFrame,
    target: &Series,
    dist: &[f64],
    h: &R
) -> f64
    where R: Regressor
{
    residuals_of_h(data, target, h)
        .zip(dist)
        .map(|(r, d)| d * r.abs())
        .sum::<f64>()
}


pub(super) fn predict<R>(
    index: usize,
    data: &DataFrame,
    regressors: &[R],
    weights: &[f64]
) -> f64
    where R: Regressor
{
    regressors.iter()
        .zip(weights)
        .map(|(h, w)| w * h.predict(data, index))
        .sum::<f64>()
}


