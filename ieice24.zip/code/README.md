# Solving linear regression with insensitive loss by boosting


These files are the code used in the experiments.
Note that our code uses an older version of `miniboosts` so that it is slow.


- `slboost/` is our proposed algorithm.
  This code produces `.json` format file that contains
  the output hypothesis.
    - `predict-from-json` reads the above mentioned `.json` format file
      and uses it as a predictor.
- `lightgbm/` is the code for LightGBM.
- `miniboosts/` is a collection of boosting algorithms and frameworks.
