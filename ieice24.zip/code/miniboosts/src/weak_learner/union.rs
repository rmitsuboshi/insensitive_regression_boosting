//! This file defines the union of weak learners.

/// This file provides the union of weak learners.
pub mod wl_union;

pub use wl_union::WLUnion;
