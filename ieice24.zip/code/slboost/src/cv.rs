use polars::prelude::*;
use rayon::prelude::*;

use miniboosts::prelude::*;

use crate::losses::*;


// -------------------------------------------------------------
// Constant parameters.

/// Boosting parameters
const TOLERANCE: f64 = 0.1;

/// CAP_RATIOS.len()
const CAP_SIZE: usize = 5;

/// Capping parameters
const CAP_RATIOS: [f64; CAP_SIZE] = [0.1, 0.2, 0.3, 0.4, 0.5];


/// Number of fold size
const FOLD_SIZE: usize = 5;

// -------------------------------------------------------------


/// Read the input file (with CSV format) into
/// the pair of (Data, Label)
fn df(file: &str) -> (DataFrame, Series) {
    let mut data = CsvReader::from_path(file)
        .unwrap()
        .has_header(true)
        .finish()
        .unwrap();

    let target = data.drop_in_place(&"target").unwrap();

    (data, target)
}


/// Run the cross validations,
pub(crate) fn cross_validation(path: &str) {
    println!("PATH: {path}");


    // Find the best parameter that minimizes the cv loss.
    println!("  Measuring train/test errors ...");
    let nu_ratio = find_best_param(&path);
    println!("  done.");

    println!(
        "Best capping ratios over {{0.1, 0.2, ..., 0.5}} is: \
        SLBppst: {nu_ratio:.2}"
    );


    let file = format!("{path}/train.csv");
    let (data, target) = df(&file);

    let train_size = data.shape().0;

    let tree = RTree::init(&data, &target)
        .loss_type(Loss::L1)
        .max_depth(2);

    // ---------------------------------------------------
    // SLBoost
    let mut booster = SLBoost::init(&data, &target)
        .nu(nu_ratio * train_size as f64)
        .tolerance(TOLERANCE);

    let f = booster.run(&tree);
    let file = format!("{path}/test.csv");
    let (data, target) = df(&file);

    let l1 = l1_loss(&data, &target, &f);
    let l2 = l2_loss(&data, &target, &f);
    let lm = linf_loss(&data, &target, &f);

    println!("Test losses with best param:");
    println!("\tL1:     {l1}");
    println!("\tL2:     {l2}");
    println!("\tL(inf): {lm}");
}


fn find_best_param(path: &str) -> f64 {
    let mut losses = Vec::with_capacity(FOLD_SIZE);


    for ratio in CAP_RATIOS {
        let loss = (1..=FOLD_SIZE).into_par_iter()
            .map(|k| {
                let file = format!("{path}/train-{k}.csv");
                let (data, target) = df(&file);

                let train_size = data.shape().0;


                let tree = RTree::init(&data, &target)
                    .loss_type(Loss::L1)
                    .max_depth(2);


                // ---------------------------------------------------
                // SLBoost
                let mut booster = SLBoost::init(&data, &target)
                    .nu(ratio * train_size as f64)
                    .tolerance(TOLERANCE);

                let f = booster.run(&tree);
                let file = format!("{path}/test-{k}.csv");
                let (data, target) = df(&file);
                println!("Finished {k}-th fold for cap: {ratio:.2}");

                l1_loss(&data, &target, &f)
            })
            .sum::<f64>()
            / FOLD_SIZE as f64;

        println!("Finished for cap: {ratio:.2}");
        losses.push((ratio, loss));
    }


    println!(
        "\n\
        --------------\n \
         RATIO | LOSS \n\
        --------------
        "
    );
    for (r, l) in losses.iter() {
        println!(" {r:>.3} | {l:>.3}");
    }
    println!("--------------");


    losses.into_iter()
        .min_by(|(_, a), (_, b)| a.partial_cmp(&b).unwrap())
        .unwrap().0
}



