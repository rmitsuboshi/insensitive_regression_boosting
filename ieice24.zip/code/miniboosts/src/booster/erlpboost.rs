//! ERLPBoost module.

pub mod erlpb;
mod qp_model;

pub use erlpb::ERLPBoost;

