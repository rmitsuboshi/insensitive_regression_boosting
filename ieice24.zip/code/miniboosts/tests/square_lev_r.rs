use polars::prelude::*;

use std::env;

use miniboosts::prelude::*;



/// Tests for `SquareLev.R`.
#[cfg(test)]
pub mod squarelevr_boston {
    use super::*;
    #[test]
    fn boston() {
        let mut path = env::current_dir().unwrap();
        path.push("tests/boston_housing.csv");
        let mut data = CsvReader::from_path(path)
            .unwrap()
            .has_header(true)
            .finish()
            .unwrap();


        let target = data.drop_in_place(&"MEDV").unwrap();


        let n_sample = data.shape().0 as f64;


        let mut slr = SquareLevR::init(&data, &target)
            .tolerance(5.0);
        let tree = RTree::init(&data, &target)
            .max_depth(3);


        let f = slr.run(&tree);


        let predictions = f.predict_all(&data);

        let loss = target.f64().unwrap()
            .into_iter()
            .zip(predictions)
            .map(|(t, p)| (t.unwrap() - p).powi(2))
            .sum::<f64>() / n_sample;

        println!("Loss (boston_housing.csv, SquareLevR, RTree): {loss}");
        println!("classifier: {f:?}");
        assert!(true);
    }
}


