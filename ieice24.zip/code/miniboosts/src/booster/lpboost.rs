//! LPBoost module.

pub mod lpb;
mod lp_model;

pub use lpb::LPBoost;
