//! SLBoost module.
//! SLBoost minimizes the soft LAE loss.

pub mod slb;
mod lp_model;
mod options;
mod dist;
mod utils;


pub use slb::SLBoost;
pub use options::*;

