use polars::prelude::*;
use grb::prelude::*;


use crate::hypothesis::Classifier;


/// A linear programming model for edge minimization. 
pub(super) struct QPModel {
    pub(self) model: Model,
    pub(self) gamma: Var,
    pub(self) dist: Vec<Var>,
    pub(self) constrs: Vec<Constr>,
}


impl QPModel {
    /// Initialize the LP model.
    /// arguments.
    /// - `n_sample`: Number of variables (Number of examples).
    /// - `upper_bound`: Capping parameter. `[1, n_sample]`.
    pub(super) fn init(eta: f64, n_sample: usize, upper_bound: f64)
        -> Self
    {
        let mut env = Env::new("").unwrap();
        env.set(param::OutputFlag, 0).unwrap();

        let mut model = Model::with_env("QPBoost", env).unwrap();


        // Set GRBVars
        let gamma = add_ctsvar!(model, name: "gamma", bounds: ..)
            .unwrap();

        let dist = (0..n_sample).map(|i| {
                let name = format!("d[{i}]");
                add_ctsvar!(model, name: &name, bounds: 0.0..upper_bound)
                    .unwrap()
            }).collect::<Vec<Var>>();


        // Set a constraint
        model.add_constr("sum_is_1", c!(dist.iter().grb_sum() == 1.0))
            .unwrap();


        // Update the model
        model.update().unwrap();


        // Set objective function
        let regularizer = dist.iter()
            .copied()
            .map(|d| d * d)
            .grb_sum();

        // Regularization parameter.
        // Note that `eta` is set as `1.0 / self.tolerance`.
        let c = 0.5 / eta;
        let objective = gamma + c * regularizer;
        model.set_objective(objective, Minimize).unwrap();

        model.update().unwrap();


        Self {
            model,
            gamma,
            dist,
            constrs: Vec::new(),
        }
    }


    /// Solve the edge minimization problem 
    /// over the hypotheses `h1, ..., ht` 
    /// and outputs the optimal value.
    pub(super) fn update<F>(
        &mut self,
        data: &DataFrame,
        target: &Series,
        _dist: &[f64],
        clf: Option<&F>
    ) -> Vec<f64>
        where F: Classifier
    {
        if let Some(h) = clf {
            // If we got a new hypothesis,
            // 1. append it as a new constraint, and
            // 2. optimize the model.
            let edge = target.i64()
                .expect("The target is not a dtype i64")
                .into_iter()
                .enumerate()
                .map(|(i, y)| y.unwrap() as f64 * h.confidence(data, i))
                .zip(self.dist.iter().copied())
                .map(|(yh, d)| d * yh)
                .grb_sum();


            let name = format!("{t}-th hypothesis", t = self.constrs.len());


            self.constrs.push(
                self.model.add_constr(&name, c!(edge <= self.gamma))
                    .unwrap()
            );
            self.model.update()
                .unwrap();


            self.model.optimize().unwrap();


            let status = self.model.status().unwrap();
            if status != Status::Optimal && status != Status::SubOptimal {
                panic!("Status ({status:?}) is not optimal.");
            }
        }

        self.constrs[0..].iter()
            .map(|c| self.model.get_obj_attr(attr::Pi, c).unwrap().abs())
            .collect::<Vec<_>>()
    }
}


