use polars::prelude::*;

use std::env;

use miniboosts::prelude::*;


/// Tests for `SquareLev.R`.
#[cfg(test)]
pub mod squarelevr_boston {
    use super::*;
    #[test]
    fn boston() {
        let mut path = env::current_dir().unwrap();
        path.push("tests/boston_housing.csv");
        let mut data = CsvReader::from_path(path)
            .unwrap()
            .has_header(true)
            .finish()
            .unwrap();


        let target = data.drop_in_place(&"MEDV").unwrap();


        let n_sample = data.shape().0 as f64;
        let nu_ratio = 0.2;


        let mut slr = SLBoost::init(&data, &target)
            .nu(nu_ratio * n_sample)
            .tolerance(0.1);
        let tree = RTree::init(&data, &target)
            .max_depth(2)
            .loss_type(Loss::L1);


        let f = slr.run(&tree);


        let predictions = f.predict_all(&data);


        let loss = target.f64().unwrap()
            .into_iter()
            .zip(&predictions[..])
            .map(|(t, p)| (t.unwrap() - p).abs())
            .sum::<f64>() / n_sample;
        println!("L1-Loss (boston_housing.csv, SLBoost, RTree): {loss}");

        let loss = target.f64().unwrap()
            .into_iter()
            .zip(&predictions[..])
            .map(|(t, p)| (t.unwrap() - p).powi(2))
            .sum::<f64>() / n_sample;

        println!("L2-Loss (boston_housing.csv, SLBoost, RTree): {loss}");
        // println!("classifier: {f:?}");



        let uniform_loss = target.f64().unwrap()
            .into_iter()
            .zip(predictions)
            .map(|(t, p)| (t.unwrap() - p).abs())
            .max_by(|a, b| a.partial_cmp(&b).unwrap())
            .unwrap();
        println!("Uniform loss: {uniform_loss}");

        assert!(true);
    }
}


