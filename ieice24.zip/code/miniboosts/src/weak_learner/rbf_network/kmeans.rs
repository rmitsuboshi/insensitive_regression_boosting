use polars::prelude::*;
// use rand::prelude::*;
use rand::distributions::{Distribution, Uniform}


pub(super) type Center = Vec<f64>;


pub(super) fn kmeans_plusplus(seed: u64, data: &DataFrame, k: usize)
    -> Vec<Center>
{
    let mut rng = rand::thread_rng();
    let mut centers = Vec::with_capacity(k);

}
