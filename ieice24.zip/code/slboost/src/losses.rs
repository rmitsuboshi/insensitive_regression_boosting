use polars::prelude::*;
use miniboosts::prelude::*;

pub fn l1_loss<R>(
    data: &DataFrame,
    target: &Series,
    f: &CombinedHypothesis<R>
) -> f64
    where R: Regressor
{
    let n_sample = data.shape().0;
    let predictions = f.predict_all(data);


    target.f64().unwrap()
        .into_iter()
        .zip(predictions)
        .map(|(t, p)| (t.unwrap() - p).abs())
        .sum::<f64>() / n_sample as f64
}


pub fn l2_loss<R>(
    data: &DataFrame,
    target: &Series,
    f: &CombinedHypothesis<R>
) -> f64
    where R: Regressor
{
    let n_sample = data.shape().0;
    let predictions = f.predict_all(data);


    target.f64().unwrap()
        .into_iter()
        .zip(predictions)
        .map(|(t, p)| (t.unwrap() - p).powi(2))
        .sum::<f64>() / n_sample as f64
}


pub fn linf_loss<R>(
    data: &DataFrame,
    target: &Series,
    f: &CombinedHypothesis<R>
) -> f64
    where R: Regressor
{
    let predictions = f.predict_all(data);

    target.f64().unwrap()
        .into_iter()
        .zip(predictions)
        .map(|(t, p)| (t.unwrap() - p).abs())
        .max_by(|a, b| a.partial_cmp(&b).unwrap())
        .unwrap()
}
