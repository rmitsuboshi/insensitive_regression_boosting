use crate::prelude::*;
use polars::prelude::*;
use crate::Classifier;
use crate::research::Logger;


#[macro_export]
macro_rules! impl_logger_logging {
    ($booster:ty) => {
        impl<F> Logger for $booster<'_, F>
            where F: Classifier
        {
            fn logging<L>(
                &self,
                loss_function: &L,
                test_data: &DataFrame,
                test_target: &Series,
            ) -> (f64, f64, f64)
                where L: Fn(f64, f64) -> f64
            {
                let objval = self.objective_value();
                let train = self.loss(loss_function, self.data, self.target);
                let test = self.loss(loss_function, test_data, test_target);

                (objval, train, test)
            }
        }
    }
}

impl_logger_logging! { AdaBoost }
