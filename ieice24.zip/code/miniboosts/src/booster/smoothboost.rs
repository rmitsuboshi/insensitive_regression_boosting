//! SmoothBoost module.
pub mod smoothb;

pub use smoothb::SmoothBoost;
