use polars::prelude::*;
use grb::prelude::*;


use super::utils::{
    residuals_of_h,
};
use crate::Regressor;

pub(super) struct LPModel {
    pub(self) model: Model,
    pub(self) gamma: Var,
    pub(self) dist: Vec<Var>,
    pub(self) constrs: Vec<Constr>,
}


impl LPModel {
    pub(super) fn init(size: usize, upper_bound: f64) -> Self {
        let mut env = Env::new("").unwrap();
        env.set(param::OutputFlag, 0).unwrap();

        let mut model = Model::with_env("MLPBoost", env).unwrap();


        // Set GRBVars
        let gamma = add_ctsvar!(model, name: "gamma", bounds: ..)
            .unwrap();

        let dist = (0..size).map(|i| {
                let name = format!("d[{i}]");
                add_ctsvar!(model, name: &name, bounds: 0.0..upper_bound)
                    .unwrap()
            }).collect::<Vec<Var>>();


        // Set the probability constraint
        // Note that this constraint is not an element of
        // `self.constrs` since the corresponding dual value is
        // not required.
        model.add_constr(&"sum_is_1", c!(dist.iter().grb_sum() == 1.0))
            .unwrap();


        // Set objective function
        model.set_objective(gamma, Maximize).unwrap();


        // Update the model
        model.update().unwrap();


        Self {
            model,
            gamma,
            dist,
            constrs: Vec::new(),
        }
    }


    /// Solve the edge minimization problem over the hypotheses
    /// `h1, ..., ht`.
    /// The argument `h` is the new hypothesis `ht`.
    pub(super) fn update<R>(
        &mut self,
        data: &DataFrame,
        target: &Series,
        opt_h: Option<&R>
    ) -> Vec<f64>
        where R: Regressor
    {
        // If we got a new hypothesis,
        // 1. append a constraint, and
        // 2. optimize the model.
        if let Some(h) = opt_h {
            let lae = residuals_of_h(data, target, h)
                .zip(&self.dist[..])
                .map(|(r, d)| r.abs() * *d)
                .sum::<Expr>();
            let name = format!("{t}-th hypothesis", t = self.constrs.len());
            self.constrs.push(
                self.model.add_constr(&name, c!(lae >= self.gamma)).unwrap()
            );
            self.model.update().unwrap();


            self.model.optimize().unwrap();


            let status = self.model.status().unwrap();
            if status != Status::Optimal {
                panic!("Status is {status:?}. Something wrong.");
            }
        }


        self.constrs.iter()
            .map(|c| self.model.get_obj_attr(attr::Pi, c).unwrap().abs())
            .collect::<Vec<_>>()
    }
}


