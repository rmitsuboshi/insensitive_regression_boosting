//! This is the main file for cross validation.
mod all_tests;

use all_tests::all_tests;

fn main() {
    let mut args = std::env::args().skip(1);

    let path = args.next()
        .expect("[USAGE]: ./slboost [PATH TO FOLD DATASETS]");
    let out_prefix = args.next()
        .expect("[USAGE]: ./slboost [PATH TO FOLD DATASETS]");
    all_tests(&path, &out_prefix);
}
