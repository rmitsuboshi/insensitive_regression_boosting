//! This file defines some options of MLPBoost.

use polars::prelude::*;
use rayon::prelude::*;

use super::{
    utils::*,
    dist::*,
};
use crate::Regressor;


/// Primary updates.
/// These options correspond to the Frank-Wolfe strategies.
#[derive(Clone, Copy)]
pub enum Primary {
    /// Classic step size, `2 / (t + 2)`.
    Classic,

    /// Short-step size,
    /// Adopt the step size that minimizes the strongly-smooth bound.
    ShortStep,

    /// Line-search step size,
    /// Adopt the best step size on the descent direction.
    LineSearch,

    // /// Pairwise strategy, 
    // /// See [this paper](https://arxiv.org/abs/1511.05932). 
    // Pairwise,
}


impl Primary {
    /// Returns a weight vector updated 
    /// by the Frank-Wolfe rule.
    #[inline(always)]
    pub(super) fn update<R>(
        &self,
        eta: f64,
        nu: f64,
        data: &DataFrame,
        target: &Series,
        dist: &[f64],
        position: usize,
        regressors: &[R],
        mut weights: Vec<f64>,
        iterate: usize
    ) -> Vec<f64>
        where R: Regressor
    {
        match self {
            Primary::Classic => {
                // Compute the step-size
                let lambda = 2.0_f64 / ((iterate + 1) as f64);

                // Update the weights
                weights.iter_mut()
                    .enumerate()
                    .for_each(|(i, w)| {
                        let e = if i == position { 1.0 } else { 0.0 };
                        *w = lambda * e + (1.0 - lambda) * *w;
                    });
                weights
            },


            Primary::ShortStep => {
                // Compute the step-size
                if regressors.len() == 1 {
                    return vec![1.0];
                }


                let new_h: &R = &regressors[position];

                let mut numer: f64 = 0.0;
                let mut denom: f64 = f64::MIN;

                target.f64().unwrap()
                    .into_iter()
                    .zip(dist)
                    .enumerate()
                    .for_each(|(i, (y, d))| {
                        let np = new_h.predict(data, i);
                        let op = predict(i, data, regressors, &weights[..]);

                        let res = np - op;
                        let mut sgn = (y.unwrap() - op).signum();
                        if sgn == 0.0 { sgn = 1.0; }
                        numer += sgn * d * res;
                        denom = denom.max(res.abs());
                    });

                let step = numer / (eta * denom.powi(2));

                let lambda = (step.max(0.0_f64)).min(1.0_f64);


                // Update the weights
                weights.iter_mut()
                    .enumerate()
                    .for_each(|(i, w)| {
                        let e = if position == i { 1.0 } else { 0.0 };
                        *w = lambda * e + (1.0 - lambda) * *w;
                    });
                weights
            },


            Primary::LineSearch => {
                let n_sample = data.shape().0;
                let f: &R = &regressors[position];


                // base: Aw
                // dir:  A(ej - w)
                let mut base = vec![0.0; n_sample];
                let mut dir  = base.clone();

                (0..n_sample).into_iter()
                    .for_each(|i| {
                        let fc = f.predict(data, i);
                        let wc = predict(i, data, regressors, &weights[..]);

                        dir[i]  = fc - wc;
                        base[i] = wc;
                    });


                let mut ub = 1.0;
                let mut lb = 0.0;


                // Check the step size `1`.
                let res = residuals(data, target, regressors, &dir[..])
                    .collect::<Vec<f64>>();

                let dist = dist_at(eta, nu, &res[..]);

                let edge = lae_of(
                    data,
                    target,
                    &dist[..],
                    regressors,
                    &dir[..]
                );


                if edge >= 0.0 {
                    weights.par_iter_mut()
                        .enumerate()
                        .for_each(|(i, w)| {
                            *w = if position == i { 1.0 } else { 0.0 };
                        });
                    return weights;
                }

                const SUB_TOLERANCE: f64 = 1e-9;


                while ub - lb > SUB_TOLERANCE {
                    let stepsize = (lb + ub) / 2.0;

                    let tmp = base.iter()
                        .zip(dir.iter())
                        .map(|(b, d)| b + stepsize * d)
                        .collect::<Vec<f64>>();


                    let res = residuals(data, target, regressors, &tmp[..])
                        .collect::<Vec<f64>>();

                    // Check the step size `1`.
                    let dist = dist_at(eta, nu, &res[..]);


                    let edge = lae_of(
                        data,
                        target,
                        &dist[..],
                        regressors,
                        &dir[..]
                    );

                    if edge > 0.0 {
                        lb = stepsize;
                    } else if edge < 0.0 {
                        ub = stepsize;
                    } else {
                        break;
                    }
                }

                let stepsize = (lb + ub) / 2.0;

                // Update the weights


                weights.iter_mut()
                    .enumerate()
                    .for_each(|(i, w)| {
                        let e = if position == i { 1.0 } else { 0.0 };
                        *w = stepsize * e + (1.0 - stepsize) * *w;
                    });
                weights
            },
            // Primary::Pairwise => {
            // },
        }
    }
}


/// Secondary updates.
/// You can choose the heuristic updates from these options.
#[derive(Clone, Copy)]
pub enum Secondary {
    /// LPBoost update.
    LPB,
    // /// ERLPBoost update.
    // ERLPB,
    // /// No heuristic update.
    // Nothing,
}


/// The stopping criterion of the algorithm.
/// The default criterion uses `ObjVal`.
#[derive(Clone, Copy)]
pub enum StopCondition {
    /// Uses the edge of current combined hypothesis.
    Edge,

    /// Uses the objective value.
    ObjVal,
}



