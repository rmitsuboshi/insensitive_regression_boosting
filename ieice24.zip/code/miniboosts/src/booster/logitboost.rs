//! LogitBoost algorithm.

pub mod logitb;

pub use logitb::LogitBoost;
