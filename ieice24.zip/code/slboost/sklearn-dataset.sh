home='/home/mitsuboshi/dataset/sklearn-dataset'
datasets=(
    'california-housing'
    'diabetes'
)

for dataset in ${datasets[@]} ; do
    path="${home}/${dataset}"
    jsonprefix="/home/mitsuboshi/slboost/target/release/${datasets[i]}"
    output="${datasets[i]}.txt"
    ./slboost $path $jsonprefix &> $output &
done


# home='/home/mitsuboshi/dataset/sklearn-dataset'
# datasets=(
#     'california-housing'
#     'diabetes'
# )
# 
# for dataset in ${datasets[@]} ; do
#     path="${home}/${dataset}"
#     ./slboost $path > "${dataset}.txt" &
# done
