//! This file defines `BrownBoost` based on the paper
//! ``An Adaptive Version of the Boost by Majority Algorithm''
//! by Yoav Freund.


use polars::prelude::*;
use rayon::prelude::*;

use crate::{
    Classifier,
    CombinedClassifier,
    BaseLearner,
    Booster,
};


/// BrownBoost.
pub struct BrownBoost {
    /// A positive real valued parameter.
    remaining_time: f64,

    /// A small constant used to avoid degenerate cases.
    nu: f64,


    /// Number of training examples
    n_sample: usize,
}


impl BrownBoost {
    /// Initialize `BrownBoost`.
    pub fn init(data: &DataFrame, _target: &Series) -> Self {
        let n_sample = data.shape().0;

        Self {
            remaining_time: f64::MAX,
            nu: 0.01_f64,
            n_sample,
        }
    }
}
