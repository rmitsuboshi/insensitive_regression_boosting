#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import lightgbm as lgb
import sys


def L1_loss(X, Y, gbm):
    n_sample = X.shape[0]
    
    return sum([abs(y - p) for y, p in zip(Y, gbm.predict(X))]) / n_sample


def L2_loss(X, Y, gbm):
    n_sample = X.shape[0]
    
    return sum([abs(y - p) ** 2 for y, p in zip(Y, gbm.predict(X))]) / n_sample


def Linf_loss(X, Y, gbm):
    return max([abs(y - p) for y, p in zip(Y, gbm.predict(X))])


if __name__ == "__main__":
    args = sys.argv
    if len(args) < 2:
        print("[USAGE] python3 gbm.py [PATH TO FOLD DATASETS]")
        sys.exit()


    # Path to the dataset
    PATH = args[1]

    # LightGBM parameter
    params = {
        "task": "train",
        "objective": "regression_l1",

        "boosting": "gbdt",
        "max_depth": 2,

        "seed": 1234,
        "deterministic": True,

        "lambda_l1": 1.0,

        "verbose": -1,
    }


    FOLD_SIZE = 5
    pair = list()
    ps = [1.0, 10.0, 20.0, 50.0, 100.0]

    best_lambda = None
    best_loss = 1e9

    for p in ps:
        params["lambda_l1"] = p
        
        loss = 0.0
        for k in range(0, FOLD_SIZE):
            # Train GBM
            df = pd.read_csv(f"{PATH}/train-{k+1}.csv")
            Y = df["target"]
            X = df.drop("target", axis=1)

            train_data = lgb.Dataset(X, label=Y)
            
            gbm = lgb.train(params, train_data)

            # Test the trained model by the validation dataset
            df = pd.read_csv(f"{PATH}/test-{k+1}.csv")
            Y = df["target"]
            X = df.drop("target", axis=1)

            loss += L1_loss(X, Y, gbm)
        loss /= FOLD_SIZE
        pair.append((p, loss))
        
        if best_loss > loss:
            best_loss = loss
            best_lambda = p

    print("Lambda | CV-loss")
    for p, loss in pair:
        print(f" {p:>3.1} | {loss:>3.3}")

    print(f"Best 'lambda_l1' is: {best_lambda}")

    # Set the best `lambda_l1`
    params["lambda_l1"] = best_lambda

    # Train GBM
    df = pd.read_csv(f"{PATH}/train.csv")
    Y = df["target"]
    X = df.drop("target", axis=1)

    train_data = lgb.Dataset(X, label=Y)

    gbm = lgb.train(params, train_data)

    # Test the trained model by the validation dataset
    df = pd.read_csv(f"{PATH}/test.csv")
    Y = df["target"]
    X = df.drop("target", axis=1)

    loss = L1_loss(X, Y, gbm)
    print(f"Test     (L1-)loss: {loss}")
    loss = L2_loss(X, Y, gbm)
    print(f"Test     (L2-)loss: {loss}")
    loss = Linf_loss(X, Y, gbm)
    print(f"Test (L(inf)-)loss: {loss}")
