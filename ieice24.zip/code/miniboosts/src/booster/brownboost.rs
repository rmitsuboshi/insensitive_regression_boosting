//! BrownBoost module.
pub mod brownb;

use brownb::BrownBoost;
